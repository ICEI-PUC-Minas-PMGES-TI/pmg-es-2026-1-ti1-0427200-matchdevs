function carregarBanner(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = document.getElementById('banner-img');
    img.src = e.target.result;
    img.style.display = 'block';
    perfil.bannerImg = e.target.result;
    toast('Banner atualizado!', 'sucesso');
  };
  reader.readAsDataURL(file);
}

function carregarFoto(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const src = e.target.result;
    // Avatar principal
    const avatarImg = document.getElementById('avatar-img');
    avatarImg.src = src;
    avatarImg.style.display = 'block';
    document.getElementById('avatar-inicial').style.display = 'none';
    // Nav avatar
    const navWrap = document.getElementById('nav-avatar-wrap');
    navWrap.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">`;
    perfil.fotoPerfil = src;
    toast('Foto de perfil atualizada!', 'sucesso');
  };
  reader.readAsDataURL(file);
}

/* ─── MODAIS ─── */
function abrirModal(id) {
  document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('ativo'));
  document.getElementById(id).classList.add('ativo');
}
function fecharModal(id) {
  document.getElementById(id).classList.remove('ativo');
}
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('ativo'); });
});

/* ─── TOAST ─── */
function toast(msg, tipo='') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast ativo' + (tipo ? ' ' + tipo : '');
  setTimeout(() => t.className = 'toast', 2800);
}

/* ─── SALVAR PERFIL ─── */
function salvarPerfil() {
  const campos = {
    nome: document.getElementById('edit-nome').value.trim(),
    cargo: document.getElementById('edit-cargo').value.trim(),
    empresa: document.getElementById('edit-empresa').value.trim(),
    local: document.getElementById('edit-local').value.trim(),
    email: document.getElementById('edit-email').value.trim(),
    tel: document.getElementById('edit-tel').value.trim(),
    linkedin: document.getElementById('edit-linkedin').value.trim(),
    github: document.getElementById('edit-github').value.trim(),
    disponibilidade: document.getElementById('edit-disp').value
  };
  if (!campos.nome) return;

  Object.assign(perfil, campos);
  perfil.metricas = {
    exp: document.getElementById('edit-exp').value,
    proj: document.getElementById('edit-proj').value,
    rec: document.getElementById('edit-rec').value,
    match: document.getElementById('edit-match').value
  };

  // Atualizar DOM
  document.getElementById('usuario-nome').textContent = perfil.nome;
  document.getElementById('usuario-cargo').innerHTML = `${perfil.cargo} · <strong id="usuario-empresa">${perfil.empresa}</strong>`;
  document.getElementById('usuario-local').textContent = perfil.local;
  document.getElementById('nav-nome').textContent = perfil.nome;
  document.getElementById('contato-email').textContent = perfil.email;
  document.getElementById('contato-email').href = `mailto:${perfil.email}`;
  document.getElementById('contato-tel').textContent = perfil.tel;
  document.getElementById('contato-linkedin').textContent = perfil.linkedin;
  document.getElementById('contato-github').textContent = perfil.github;

  document.getElementById('met-exp').textContent = perfil.metricas.exp;
  document.getElementById('met-proj').textContent = perfil.metricas.proj;
  document.getElementById('met-rec').textContent = perfil.metricas.rec;
  document.getElementById('met-match').textContent = perfil.metricas.match;

  // Badge disponibilidade
  const badge = document.getElementById('badge-disp');
  if (perfil.disponibilidade === 'disponivel') { badge.textContent = '● Disponível'; badge.className = 'badge badge-success'; badge.style.display = ''; }
  else if (perfil.disponibilidade === 'passivo') { badge.textContent = '◐ Aberto passivamente'; badge.className = 'badge badge-premium'; badge.style.display = ''; }
  else { badge.style.display = 'none'; }

  // Atualiza inicial se não tiver foto
  if (!perfil.fotoPerfil) {
    const ini = perfil.nome[0].toUpperCase();
    document.getElementById('avatar-inicial').textContent = ini;
    const nw = document.getElementById('nav-avatar-wrap');
    if (!nw.querySelector('img')) nw.querySelector('#nav-inicial').textContent = ini;
  }

  // Footer email
  document.querySelector('.footer p') && (document.querySelector('.footer p').innerHTML = `BH<span>WORKS</span> · ${perfil.email}`);

  fecharModal('modal-editar');
  toast('Perfil atualizado!', 'sucesso');
  salvarJSON();
}

/* ─── SOBRE ─── */
function salvarSobre() {
  const txt = document.getElementById('edit-sobre').value.trim();
  perfil.sobre = txt;
  const el = document.getElementById('sobre-texto');
  el.textContent = txt;
  el.classList.add('truncado');
  document.getElementById('btn-ver-mais').textContent = 'Ver mais ▾';
  fecharModal('modal-sobre');
  toast('Sobre atualizado!', 'sucesso');
  salvarJSON();
}
function verMais() {
  const el = document.getElementById('sobre-texto');
  const btn = document.getElementById('btn-ver-mais');
  if (el.classList.contains('truncado')) { el.classList.remove('truncado'); btn.textContent = 'Ver menos ▴'; }
  else { el.classList.add('truncado'); btn.textContent = 'Ver mais ▾'; }
}

/* ─── MENSAGEM ─── */
function enviarMsg() {
  const msg = document.getElementById('msg-texto').value.trim();
  if (!msg) return;
  fecharModal('modal-msg');
  toast('Mensagem enviada!', 'sucesso');
  document.getElementById('msg-texto').value = '';
}

/* ─── CONECTAR ─── */
function conectar() {
  const btn = document.getElementById('btn-conectar');
  btn.innerHTML = '✓ Conectado';
  btn.style.background = 'var(--success)';
  btn.disabled = true;
  toast('Convite enviado!', 'sucesso');
}

/* ─── EXPERIÊNCIA ─── */
function adicionarExp() {
  const cargo = document.getElementById('exp-cargo').value.trim();
  const empresa = document.getElementById('exp-empresa').value.trim();
  const inicio = document.getElementById('exp-inicio').value;
  const fim = document.getElementById('exp-fim').value;
  const local = document.getElementById('exp-local').value.trim();
  const modo = document.getElementById('exp-modo').value;
  const desc = document.getElementById('exp-desc').value.trim();
  const tagsVal = document.getElementById('exp-tags').value;
  if (!cargo || !empresa) return;

  const periodo = (inicio ? fmtMes(inicio) : '') + ' – ' + (fim ? fmtMes(fim) : 'Presente') + (local ? ' · ' + local : '') + (modo ? ' · ' + modo : '');
  const tags = tagsVal ? tagsVal.split(',').map(t => `<span class="exp-tag">${t.trim()}</span>`).join('') : '';
  const ini = empresa[0].toUpperCase();
  const cor = `hsl(${Math.round(Math.random()*360)},60%,60%)`;

  const html = `<div class="exp-item">
    <div class="exp-icone" style="background:${cor}22;border-color:${cor}66;color:${cor};">${ini}</div>
    <div class="exp-corpo">
      <div class="exp-titulo">${cargo}</div>
      <div class="exp-empresa">${empresa} · ${modo}</div>
      <div class="exp-periodo">${periodo}</div>
      ${desc ? `<div class="exp-desc">${desc}</div>` : ''}
      ${tags ? `<div class="exp-tags">${tags}</div>` : ''}
    </div>
  </div>`;
  document.getElementById('exp-lista').insertAdjacentHTML('afterbegin', html);
  const c = document.querySelectorAll('.exp-item').length;
  document.getElementById('exp-count').textContent = c + ' cargo' + (c > 1 ? 's' : '');
  fecharModal('modal-exp');
  toast('Experiência adicionada!', 'sucesso');
  ['exp-cargo','exp-empresa','exp-inicio','exp-fim','exp-local','exp-desc','exp-tags'].forEach(id => document.getElementById(id).value = '');
}

function fmtMes(val) {
  if (!val) return '';
  const [y, m] = val.split('-');
  const meses = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
  return meses[parseInt(m)-1] + ' ' + y;
}

/* ─── EDUCAÇÃO ─── */
function adicionarEdu() {
  const curso = document.getElementById('edu-curso').value.trim();
  const inst = document.getElementById('edu-inst').value.trim();
  const ini = document.getElementById('edu-inicio').value;
  const fim = document.getElementById('edu-fim').value;
  if (!curso || !inst) return;
  const html = `<div class="edu-item">
    <div class="edu-icone">🎓</div>
    <div><div class="edu-titulo">${curso}</div><div class="edu-inst">${inst}</div><div class="edu-periodo">${ini}${fim ? ' – ' + fim : ''}</div></div>
  </div>`;
  document.getElementById('edu-lista').insertAdjacentHTML('afterbegin', html);
  fecharModal('modal-edu');
  toast('Educação adicionada!', 'sucesso');
  ['edu-curso','edu-inst','edu-inicio','edu-fim'].forEach(id => document.getElementById(id).value = '');
}

/* ─── HABILIDADES ─── */
function adicionarHab() {
  const nome = document.getElementById('hab-nome').value.trim();
  if (!nome) return;
  document.getElementById('hab-grid').insertAdjacentHTML('afterbegin', `<div class="hab-item">${nome}</div>`);
  fecharModal('modal-hab');
  toast('Habilidade adicionada!', 'sucesso');
  document.getElementById('hab-nome').value = '';
}

/* ─── CERTIFICAÇÃO ─── */
function adicionarCert() {
  const nome = document.getElementById('cert-nome').value.trim();
  const emissor = document.getElementById('cert-emissor').value.trim();
  const ano = document.getElementById('cert-ano').value;
  if (!nome) return;
  const html = `<div class="cert-item"><div class="cert-icone">🏅</div><div><div class="cert-nome">${nome}</div><div class="cert-emissor">${emissor}</div></div><div class="cert-ano">${ano}</div></div>`;
  document.getElementById('cert-lista').insertAdjacentHTML('afterbegin', html);
  fecharModal('modal-cert');
  toast('Certificação adicionada!', 'sucesso');
  ['cert-nome','cert-emissor','cert-ano'].forEach(id => document.getElementById(id).value = '');
}

/* ─── EXPORTAR JSON ─── */
function salvarJSON() {
  const dados = JSON.parse(JSON.stringify(perfil));
  // Não serializar imagens grandes no log
  dados.fotoPerfil = dados.fotoPerfil ? '[imagem carregada]' : null;
  dados.bannerImg = dados.bannerImg ? '[imagem carregada]' : null;
  console.log('Perfil JSON atual:', JSON.stringify(dados, null, 2));
}